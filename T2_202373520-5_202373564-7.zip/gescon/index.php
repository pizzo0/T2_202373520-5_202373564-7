<?php


require "./php/config/config.php";
require "./php/config/func.php";

init();