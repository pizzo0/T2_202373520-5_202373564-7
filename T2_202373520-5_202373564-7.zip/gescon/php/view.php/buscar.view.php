<script src=<?php getJs(js_file: "crearPreview");?>></script>
<?php


$titulo = "Articulos";
$filtro_extra = false;
include "buscar.componente.view.php";
?>
<script src=<?php getJs("modal");?>></script>