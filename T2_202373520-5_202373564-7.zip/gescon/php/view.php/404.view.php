<div class="big-bg-text"><h1 class="gloock">404</h1></div>
<div class="menu bg-blur">
    <h1>404</h1>
    <p>
        Página no encontrada - La página que estás buscando no existe, ha sido movida o no tienes acceso a ella :(
    </p>
    <button onclick="location.href='/'">Volver al inicio</button>
</div>