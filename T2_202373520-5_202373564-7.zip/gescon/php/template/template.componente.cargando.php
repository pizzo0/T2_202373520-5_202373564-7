<div class="loading-container" id="loading">
    <div class="loading-bar">
    </div>
</div>
<script src=<?php getJs(js_file: "loadingAnimacion");?>></script>